const { Client } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client();

client.on('qr', (qr) => {
    qrcode.generate(qr, {small: true});
});

client.on('ready', async () => {
    console.log('Client is ready!');

    const chats = await client.getChats();
    const groups = chats.filter(chat => chat.isGroup);

    groups.forEach(group => {
        console.log(`Nombre: ${group.name}`);
        console.log(`ID: ${group.id._serialized}`);
        console.log('---------------------');
    });
});

client.initialize();
